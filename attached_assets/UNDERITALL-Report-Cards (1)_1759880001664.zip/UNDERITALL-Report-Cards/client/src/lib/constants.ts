// This file is kept for potential future constants
// SAMPLE_ORDER has been removed as we now fetch live data from Shopify
